function formatarTelefone(input) {
    const value = input.value.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
    let formattedValue = '';

    if (value.length <= 11) {
        formattedValue = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }

    input.value = formattedValue;
}

function verificarEmail(email) {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
}

function verificarSenhas() {
    const senha1 = document.getElementById('senha1').value;
    const senha2 = document.getElementById('senha2').value;
    const mensagem = document.getElementById('mensagem-senhas');

    if (senha1 === senha2) {
        mensagem.textContent = 'As senhas coincidem.';
    } else {
        mensagem.textContent = 'As senhas não coincidem.';
    }
}

function verificarCamposEtapa1() {
    const nome = document.getElementById('nome').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const email = document.getElementById('email').value.trim();
    const senha1 = document.getElementById('senha1').value;
    const senha2 = document.getElementById('senha2').value;

    if (nome === '' || telefone === '' || email === '' || senha1 === '' || senha2 === '') {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return false;
    }

    if (!verificarEmail(email)) {
        alert('Por favor, insira um email válido.');
        return false;
    }

    if (telefone.length < 10) {
        alert('Por favor, insira um número de telefone válido.');
        return false;
    }

    if (senha1 !== senha2) {
        alert('As senhas não coincidem. Por favor, verifique.');
        return false;
    }

    return true;
}

function verificarCamposEtapa2() {
    const filmeEscolhido = document.getElementById('filmes').value;
    const horarioEscolhido = document.getElementById('horario').value;
    const legendasElement = document.querySelector('input[name="legendas"]:checked');

    if (!filmeEscolhido || !horarioEscolhido || !legendasElement) {
        alert('Por favor, selecione todos os campos obrigatórios.');
        return false;
    }

    if (!legendasElement) {
        alert('Por favor, selecione se deseja legendado ou dublado.');
        return false;
    }

    return true;
}

function replaceInfos() {
    
    if (verificarCamposEtapa1()) {
        const divLogar = document.querySelector('#div_logar');
        const divFilme = document.querySelector('#div_filme');

        divLogar.style.display = 'none';
        divFilme.style.display = 'block';
    }
}

function replaceInfos2() {
    if (verificarCamposEtapa2()) {
        const divFilme = document.querySelector('#div_filme');
        const divAlimento = document.querySelector('#div_alimento');

        divFilme.style.display = 'none';
        divAlimento.style.display = 'block';
    }
}


function formatar_itens(str) {
    const formatacaoItens = {
        "manha": "Manhã",
        "tarde": "Tarde",
        "noite": "Noite",
        "legendado": "Legendado",
        "dublado": "Dublado",
        "pizza": "Pizza",
        "hamburguer": "Hamburguer",
        "sushi": "Sushi",
        "macarrao": "Macarrão",
        "coca": "Coca-Cola",
        "fanta": "Fanta",
        "sprite": "Sprite"
    };

    return formatacaoItens[str] || str;
}
function exibirInfos() {
    const nomeElement = document.querySelector('#nome');
    const nome = nomeElement.value;

    const telefoneElement = document.querySelector('#telefone');
    const telefone = telefoneElement.value;

    const emailElement = document.querySelector('#email');
    const email = emailElement.value;

    const filmeElement = document.querySelector('#filmes');
    const filmeEscolhido = filmeElement.value;

    const horarioElement = document.querySelector('#horario');
    const horarioEscolhido = horarioElement.value;

    const legendasElement = document.querySelector('input[name="legendas"]:checked');
    const legendas = legendasElement ? legendasElement.value : '';

    const comidaElement = document.querySelector('#comidas');
    const comidaEscolhida = comidaElement.value;

    const refrigeranteElement = document.querySelector('#refrigerante');
    const refrigeranteEscolhido = refrigeranteElement.value;

    const infoContainer = document.querySelector('#infoContainer');

    const horarioEscolhidoFormatado = formatar_itens(horarioEscolhido);
    const legendasFormatadas = formatar_itens(legendas);
    const comidaEscolhidaFormatada = formatar_itens(comidaEscolhida);
    const refrigeranteEscolhidoFormatado = formatar_itens(refrigeranteEscolhido);

    const dataElement = document.querySelector('#data');
    const dataEscolhida = dataElement.value;

    const dataFormatada = new Date(dataEscolhida).toLocaleDateString('pt-BR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    const filmeImagemMap = {
        "Vingadores: Ultimato": "vingadores",
        "Harry Potter e a Pedra Filosofal": "harrypotter",
        "Matrix": "matrix",
        "Star Wars: O Império Contra-Ataca": "starwars"};

        const bebidaImagemMap = {
            "Coca-Cola": "coca",
            "Fanta": "fanta",
            "Sprite": "sprite"
        };
    
        const alimentoImagemMap = {
            "Pizza": "pizza",
            "Hamburguer": "hamburguer",
            "Sushi": "sushi",
            "Macarrão": "macarrao"
        };
    
        const caminhoImagens = 'imagens/';

        const filmeImagem = caminhoImagens + filmeImagemMap[filmeEscolhido] + '.jpg';
        const alimentoImagem = caminhoImagens + alimentoImagemMap[comidaEscolhidaFormatada] + '.jpg';
        const bebidaImagem = caminhoImagens + bebidaImagemMap[refrigeranteEscolhidoFormatado] + '.jpg';

        const imgenstamanho = 'max-width: 275px; height: auto;';

        const imagensHTML = `
        <h1>SESSÃO MARCADA!</h1>
        <h2>Tenha um ótimo filme!</h2>
        <p><strong>Nome:</strong> ${nome}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Telefone:</strong> ${telefone}</p>
        <p><strong>Filme favorito:</strong> ${filmeEscolhido}</p>
        <p><strong>Data escolhida:</strong> ${dataFormatada}</p>
        <p><strong>Horário escolhido:</strong> ${horarioEscolhidoFormatado}</p>
        <p><strong>Legendas ou Dublado:</strong> ${legendasFormatadas}</p>
        <p><strong>Comida favorita:</strong> ${comidaEscolhidaFormatada}</p>
        <p><strong>Refrigerante escolhido:</strong> ${refrigeranteEscolhidoFormatado}</p>
        <div id="div_imagens" style="background-color: white; padding: 10px; display:inline-block; border-radius: 15px; border: 3px dashed #ff6600;">
            <img src="${filmeImagem}" alt="Banner do Filme" style="max-width: 300px; height: auto;">
            <img src="${alimentoImagem}" alt="Imagem do Alimento" style="max-width: 300px; height: auto;">
            <img src="${bebidaImagem}" alt="Imagem da Bebida" style="max-width: 300px; height: auto;">
        </div>
    `;
    
    infoContainer.innerHTML = imagensHTML;
    infoContainer.style.display = 'block';
    

    // Esconde a div de escolha de alimento
    const divAlimento = document.querySelector('#div_alimento');
    divAlimento.style.display = 'none';

   

}
